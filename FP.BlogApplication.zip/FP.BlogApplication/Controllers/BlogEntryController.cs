﻿using FP.BlogApplication.Data;
using FP.BlogApplication.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace FP.BlogApplication.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class BlogEntryController : ControllerBase
    {
        private readonly BlogContext _logger;

        public BlogEntryController(BlogContext logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<BlogEntry>>> GetEntries()
        {
            return await _logger.Entries.ToListAsync();
        }

        // GET: api/Data/5
        [HttpGet("{id}")]
        public async Task<ActionResult<BlogEntry>> GetBlogEntry(long id)
        {
            var blogEntry = await _logger.Entries.FindAsync(id);

            if (blogEntry == null)
            {
                return NotFound();
            }

            return blogEntry;
        }

        // PUT: api/Data/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutBlogEntry(long id, BlogEntry blogEntry)
        {
            if (id != blogEntry.Id)
            {
                return BadRequest();
            }

            _logger.Entry(blogEntry).State = EntityState.Modified;

            try
            {
                await _logger.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BlogEntryExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Data
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<BlogEntry>> PostBlogEntry(BlogEntry blogEntry)
        {
            _logger.Entries.Add(blogEntry);

            await _logger.SaveChangesAsync();

            return CreatedAtAction("GetBlogEntry", new { id = blogEntry.Id }, blogEntry);
        }

        // DELETE: api/Data/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEntries(long id)
        {
            var blogEntry = await _logger.Entries.FindAsync(id);

            if (blogEntry == null)
            {
                return NotFound();
            }

            _logger.Entries.Remove(blogEntry);

            await _logger.SaveChangesAsync();

            return NoContent();
        }

        private bool BlogEntryExists(long id)
        {
            return _logger.Entries.Any(e => e.Id == id);
        }
    }
}
