using System;

namespace FP.BlogApplication.Models
{
    public class BlogEntry
    {
        public long Id { get; set; }
        public string Title { get; set; }
        public string Body { get; set; }
        public bool IsPublished { get; set; }
        public DateTime? DatePublished { get; set; }
    }
}
