﻿using FP.BlogApplication.Models;
using Microsoft.EntityFrameworkCore;



namespace FP.BlogApplication.Data
{
    public class BlogContext : DbContext
    {
        public BlogContext()
        { }

        public BlogContext(DbContextOptions<BlogContext> options) : base(options)
        { }

        public DbSet<BlogEntry> Entries { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseInMemoryDatabase("blogentry");
        }
    }
}