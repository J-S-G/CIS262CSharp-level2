using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using System.Threading.Tasks;

namespace FP.BlogApplication
{
    public class Program
    {
        public static Task Main(string[] args)
        {
            IHost host = CreateHostBuilder(args);

            return host.RunAsync();
        }

        public static IHost CreateHostBuilder(string[] args)
        {
            IHostBuilder builder = Host.CreateDefaultBuilder(args);

            builder = builder.ConfigureWebHostDefaults(webBuilder => webBuilder.UseStartup<Startup>());

            IHost host = builder.Build();

            return host;
        }
    }
}
